import axios from "axios";

const BASE_URL = "http://localhost:8080/users";
const api = axios.create({ baseURL: BASE_URL });

export function login(data) {
  return api.post("", data);
}
