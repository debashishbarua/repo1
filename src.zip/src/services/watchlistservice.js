import axios from "axios";

const BASE_URL = "http://localhost:8080/watchList";
const api = axios.create({ baseURL: BASE_URL });

export function addWatchList(data) {
  return api.post("", data);
}

export function deleteWatchList(id) {
  return api.delete("/delete/" + id);
}
