import React, { Component } from "react";
class MountComponent extends Component {
  constructor(props) {
    super(props);
    console.log("Constructor Executed");
  }

  render() {
    return (
      <div>
        <h1>Mount Phase</h1>
      </div>
    );
  }
  componentDidMount() {
    console.log("componentDidMount Executed");
  }
  componentDidUpdate() {
    console.log("componentDidUpdate Executed");
  }
  componentWillUnmount() {
    console.log("componentWillUnmount Executed");
  }
  componentDidCatch() {
    console.log("componentDidCatch Executed");
  }
}

export default MountComponent;
