import axios from "axios";
import React, { Component } from "react";
import { Button, Col, Container, Form, Row, Table } from "react-bootstrap";

class PerformanceComponent extends Component {
  state = {
    companystocks: [],
    companies: [],
    companyCode1: "",
    companyCode2: "",
    from: "",
    to: "",
  };
  constructor(props) {
    super(props);
    this.props.onLogin(localStorage.getItem("userId"));
  }
  componentDidMount() {
    axios
      .get("http://localhost:8080/companies")
      .then((res) => {
        console.log("Response:");
        console.log(res);
        this.setState({ companies: res.data });
        this.props.onLogin(localStorage.getItem("userId"));
      })
      .catch((err) => {
        console.log("Error");
      });
    //this.props.onLogin(localStorage.getItem("userId"));
  }
  handleChange = (e) => {
    console.log(e.target.name);
    console.log(e.target.value);
    this.setState({
      [e.target.name]: e.target.value,
    });
  };
  render() {
    return (
      <>
        <Container>
          <Form onSubmit={this.handleSubmit}>
            <Row>
              <Col sm={6}>
                <Form.Group className="mb-3" controlId="companyCode1">
                  <Form.Label>Select company 1</Form.Label>
                  <Form.Select
                    size="sm"
                    onChange={this.handleChange}
                    // value={this.state.companyCode1}
                    name="companyCode1"
                  >
                    <option>choose...</option>
                    {this.state.companies.map((company) => (
                      <option
                        value={company.companyId}
                        key={company.companyId + company.companyName}
                      >
                        {company.companyName}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
              </Col>
              <Col sm={6}>
                <Form.Group className="mb-3" controlId="companyCode2">
                  <Form.Label>Select company 2</Form.Label>
                  <Form.Select
                    size="sm"
                    onChange={this.handleChange}
                    // value={this.state.companyCode2}
                    name="companyCode2"
                  >
                    <option>choose...</option>
                    {this.state.companies.map((company) => (
                      <option
                        value={company.companyId}
                        key={company.companyId + company.companyName}
                      >
                        {company.companyName}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col sm={6}>
                <Form.Group className="mb-3" controlId="from">
                  <Form.Label>Form Date</Form.Label>
                  <Form.Control
                    type="date"
                    onChange={this.handleChange}
                    name="from"
                  />
                </Form.Group>
              </Col>
              <Col sm={6}>
                <Form.Group className="mb-3" controlId="to">
                  <Form.Label>To Date</Form.Label>
                  <Form.Control
                    type="date"
                    onChange={this.handleChange}
                    name="to"
                  />
                </Form.Group>
              </Col>
            </Row>

            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>#</th>
                <th>Date</th>
                <th>Company</th>
                <th>Stock Price</th>
              </tr>
            </thead>
            <tbody>
              {this.state.companystocks &&
                this.state.companystocks.map((stock) => {
                  return (
                    <tr key={stock.id}>
                      <td>{stock.id}</td>
                      <td>{stock.date}</td>
                      <td>{stock.company.companyName}</td>
                      <td>{stock.stockPrice}</td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
        </Container>
      </>
    );
  }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state.companyCode1);
    const searchParams = new URLSearchParams();
    searchParams.append("companyCode1", this.state.companyCode1);
    searchParams.append("companyCode2", this.state.companyCode2);
    searchParams.append("from", this.state.from);
    searchParams.append("to", this.state.to);

    console.log("Data Submitted: ", searchParams.toString());
    axios
      .get(`http://localhost:8080/stocks/compare-performance?${searchParams}`)
      .then((res) => {
        this.setState({ companystocks: res.data });
      })
      .catch((err) => {
        console.log("Error");
        console.log(err.response);
      });
  };
}

export default PerformanceComponent;
