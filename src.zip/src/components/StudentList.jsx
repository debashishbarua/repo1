import React, { Component } from "react";
import StudentDetails from "./StudentDetails";
class StudentList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      students: [],
    };
  }
  componentDidMount() {
    fetch("http://localhost:3001/students")
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        this.setState({ students: data });
      })
      .catch(console.log);
  }
  render() {
    return this.state.students.map((student) => {
      return (
        <tbody key={student.id}>
          <StudentDetails student={student} />
        </tbody>
      );
    });
  }
}

export default StudentList;
