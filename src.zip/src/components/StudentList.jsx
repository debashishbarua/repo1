import React, { Component } from "react";
import StudentDetails from "./StudentDetails";
class StudentList extends Component {
  render() {
    let students = [
      { id: 100, firstName: "Akash", lastName: "Verma" },
      { id: 101, firstName: "Akash", lastName: "Verma" },
      { id: 102, firstName: "Akash", lastName: "Verma" },
    ];

    return students.map((stu) => {
      return <StudentDetails student={stu} />;
    });
    // return (
    //   <div>
    //     <StudentDetails student={students[0]} />
    //     <StudentDetails student={students[1]} />
    //     <StudentDetails student={students[2]} />
    //   </div>
    // );
  }
}

export default StudentList;
