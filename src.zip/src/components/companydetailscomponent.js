import axios from "axios";
import { Button, Card } from "react-bootstrap";

function CompanyDetailsComponent(props) {
  let { companyId, companyName, description, currentStockPrice } =
    props.company;
  let { id } = props;

  const handleButtonClick = (param, mode) => {
    // let {watchlistid} = props;
    let userId = localStorage.getItem("userId");
    let companyId = param.companyId;
    let body = { userId: userId, companyId: companyId };
    if (mode === "add") {
      axios
        .post("http://localhost:8080/watchList", body)

        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err.response.data);
        });
      alert("Successfully added to the watch list");
    } else {
      let id = param.id;
      axios
        .delete("http://localhost:8080/watchList/delete/" + id)

        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err);
        });
      alert("Remove sucessfully from watch list");
    }
  };
  return (
    <Card
      className="text-center"
      border="primary"
      style={{ width: "30rem", height: "20rem" }}
    >
      <Card.Header>{companyName}</Card.Header>
      <Card.Body>
        <Card.Text>{description}</Card.Text>
      </Card.Body>
      <Card.Footer className="text-muted">
        Today's price:${currentStockPrice}
        <Button
          style={{
            margin: ".5rem",
          }}
          variant="primary"
          onClick={() => handleButtonClick({ companyId }, "add")}
        >
          Watch
        </Button>
        <Button
          style={{
            margin: ".5rem",
          }}
          variant="danger"
          onClick={() => handleButtonClick({ id }, "remove")}
        >
          Remove
        </Button>
      </Card.Footer>
    </Card>
  );
}

export default CompanyDetailsComponent;
