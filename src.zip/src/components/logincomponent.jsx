import React, { Component } from "react";
import { Button, Form } from "react-bootstrap";
import { login } from "../services/authservice";
import WatchListComponent from "./watchlistcomponent";
class LoginComponent extends Component {
  state = {
    email: "",
    password: "",
    hasLoginFailed: false,
    errorMsg: "",
  };

  handleChange = (e) => {
    console.log(e.target.name, " " + e.target.value);
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      email: this.state.email,
      password: this.state.password,
    };
    // Call the Rest API
    login(data)
      .then((response) => {
        localStorage.setItem("userId", response.data.id);
        this.props.onLogin(localStorage.getItem("userId"));
        this.setState({ hasLoginFailed: true });
        this.setState({ showSuccessMessage: true });
        console.log(response.data);
      })
      .catch((err) => {
        console.log("Error", err.response.data);
        this.setState({ errorMsg: err.response.data });
      });
  };
  render() {
    if (this.state.hasLoginFailed) {
      return <WatchListComponent />;
    } else {
      return (
        <div>
          {!this.state.hasLoginFailed && <span>{this.state.errorMsg}</span>}
          <Form onSubmit={this.handleSubmit}>
            <Form.Group className="mb-3" controlId="email">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                name="email"
                placeholder="Enter email"
                onChange={this.handleChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="password">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                name="password"
                placeholder="Password"
                onChange={this.handleChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
              <Form.Check type="checkbox" label="Check me out" />
            </Form.Group>
            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        </div>
      );
    }
  }
}

export default LoginComponent;
