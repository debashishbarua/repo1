import React, { Component } from "react";
import CompanyDetailsComponent from "./companydetailscomponent";
class CompanyListComponent extends Component {
  state = {
    companies: [],
  };

  constructor(props) {
    super(props);
    this.props.onLogin(localStorage.getItem("userId"));
  }
  componentDidMount() {
    fetch("http://localhost:8080/companies")
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        this.setState({ companies: data });
      })
      .catch(console.log);
  }
  render() {
    return (
      <>
        <h1
          style={{
            margin: "2rem",
          }}
        >
          Compines List
        </h1>
        {this.state.companies.map((company) => {
          return (
            <div
              key={company.companyId}
              style={{
                display: "inline-flex",
                justifyContent: "space-between",
                margin: ".5rem",
                width: "26rem",
              }}
            >
              <CompanyDetailsComponent company={company} />
            </div>
          );
        })}
      </>
    );
  }
}

export default CompanyListComponent;
