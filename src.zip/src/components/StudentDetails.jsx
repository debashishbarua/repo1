import React, { Component } from "react";
class StudentDetails extends Component {
  render() {
    return (
      <div>
        <h3>
          {this.props.student.id} - {this.props.student.firstName}-
          {this.props.student.lastName}
        </h3>
      </div>
    );
  }
}

export default StudentDetails;
