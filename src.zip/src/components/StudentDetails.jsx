import React, { Component } from "react";
class StudentDetails extends Component {
  render() {
    return (
      <tr>
        <td> {this.props.student.id}</td>
        <td>{this.props.student.firstName}</td>
        <td>{this.props.student.lastName}</td>
      </tr>
    );
  }
}

export default StudentDetails;
