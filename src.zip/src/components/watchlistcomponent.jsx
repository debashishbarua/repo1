import React, { Component } from "react";
import CompanyDetailsComponent from "./companydetailscomponent";
class WatchListComponent extends Component {
  state = {
    watchlists: [],
  };
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    const url =
      "http://localhost:8080/watchList/" + localStorage.getItem("userId");
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        console.log("Data: ", data);
        this.setState({ watchlists: data });
        this.props.onLogin(localStorage.getItem("userId"));
      })
      .catch(console.log);
  }

  render() {
    if (this.state.watchlists.length === 0)
      return (
        <>
          <h1
            style={{
              margin: "2rem",
            }}
          >
            My Compines List
          </h1>
          <h3
            style={{
              margin: "2rem",
            }}
          >
            No company stock price added to the watch list.{" "}
          </h3>
        </>
      );
    else
      return (
        <>
          <h1
            style={{
              margin: "2rem",
            }}
          >
            My Compines List
          </h1>
          {this.state.watchlists.map((wl) => {
            return (
              <div
                key={wl.company.companyId}
                style={{
                  display: "inline-flex",
                  justifyContent: "space-between",
                  margin: ".5rem",
                  width: "26rem",
                }}
              >
                <CompanyDetailsComponent company={wl.company} id={wl.id} />
              </div>
            );
          })}
        </>
      );
  }
}

export default WatchListComponent;
