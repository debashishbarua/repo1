import React, { Component } from "react";

class Footer extends Component {
  render() {
    return (
      <div>
        <h1>Footer</h1>
      </div>
    );
  }
}

export default Footer;
