const Header = () => {
  return (
    <div>
      <h1> ABC Ltd.</h1>
      <h2> India</h2>
    </div>
  );
};

export default Header;

// export default function Header() {
//   return (
//     <div>
//       <h1> ABC Ltd.</h1>
//       <h2> India</h2>
//     </div>
//   );
// }
