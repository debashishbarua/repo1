import { Nav, Navbar } from "react-bootstrap";
import Container from "react-bootstrap/Container";

function MenuComponent(props) {
  return (
    <div>
      <Navbar bg="primary" variant="light" expand="lg">
        <Container>
          <Navbar.Brand href="/login">mStaockApp</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            {props.loginStatus ? (
              <Nav className="me-auto">
                <Nav.Link href="/companieslist">Companies</Nav.Link>
                <Nav.Link href="/watchlist">Watch List</Nav.Link>
                <Nav.Link href="/performance">ComparePerformance</Nav.Link>
                <Nav.Link href="/" onClick={props.logout}>
                  Logout
                </Nav.Link>
              </Nav>
            ) : (
              <Nav className="me-auto">
                <Nav.Link href="/">Login</Nav.Link>
                <Nav.Link href="/companieslist">Companies</Nav.Link>
              </Nav>
            )}
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
}

export default MenuComponent;
