import { useState } from "react";

const LoginComponentUsingFunction = () => {
  const [firstName, setFirstName] = useState();
  const [lastName, setLastName] = useState();
  const [firstNameError, setFirstNameError] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Handle Submit");
    console.log("First Name: " + firstName.value);
    console.log("Last Name: " + lastName.value);
    console.log("firstNameError: " + firstNameError.value);
  };

  const handdleChange = (e) => {
    e.preventDefault();
    const { name, value } = e.target;
    switch (name) {
      case "firstName":
        setFirstName({ value: value });
        let msg = value.length < 3 ? "Name Should be More then 3 Char" : "";
        setFirstNameError({ value: msg });
        break;
      case "lastName":
        setLastName({ value: value });
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <h1>Form Demo</h1>
      <hr />
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="firstName">First Name</label>
          <input type="text" name="firstName" onChange={handdleChange} />
        </div>

        <div>
          <label htmlFor="lastName">Last Name</label>
          <input type="text" name="lastName" onChange={handdleChange} />
        </div>

        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default LoginComponentUsingFunction;
