import React, { Component } from "react";

import LoginComponentAlt from "./components/LoginComponentAlt";
class App extends Component {
  state = {};
  render() {
    return (
      <div>
        <LoginComponentAlt />
      </div>
    );
  }
}

export default App;
// function App() {
//   return (
//     <div>
//       <Header />
//       <StudentList />
//       <Footer />
//     </div>
//   );
// }

// export default App;
