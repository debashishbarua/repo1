import { useState, useEffect, useRef } from "react";
import { Container } from "react-bootstrap";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import CompaniesListComponent from "./components/companylistcomponent";
import LoginComponent from "./components/logincomponent";
import MenuComponent from "./components/menucomponent";
import PerformanceComponent from "./components/performancecomponent";
import WatchListComponent from "./components/watchlistcomponent";
import { Outlet } from "react-router-dom";

function App() {
  let [isLoggedIn, setLoggedIn] = useState(false);

  const handleLogin = (userId) => {
    if (!userId) return;
    setLoggedIn(true);
    localStorage.setItem("userId", userId);
  };

  const handleLogout = () => {
    localStorage.clear();
  };

  return (
    <Container>
      <MenuComponent loginStatus={isLoggedIn} logout={handleLogout} />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginComponent onLogin={handleLogin} />} />
          <Route
            path="watchlist"
            element={<WatchListComponent onLogin={handleLogin} />}
          />
          <Route
            path="companieslist"
            element={<CompaniesListComponent onLogin={handleLogin} />}
          />
          <Route
            path="performance"
            element={<PerformanceComponent onLogin={handleLogin} />}
          />
        </Routes>
      </BrowserRouter>
      <Outlet />
    </Container>
  );
}

export default App;
