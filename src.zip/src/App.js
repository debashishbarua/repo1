import React, { Component } from "react";

import Footer from "./components/Footer";
import Header from "./components/Header";
import StudentList from "./components/StudentList";
class App extends Component {
  state = {};
  render() {
    return (
      <div>
        <Header />
        <StudentList />
        <Footer />
      </div>
    );
  }
}

export default App;
// function App() {
//   return (
//     <div>
//       <Header />
//       <StudentList />
//       <Footer />
//     </div>
//   );
// }

// export default App;
