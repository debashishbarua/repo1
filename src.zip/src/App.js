import React from "react";
import { MemoryRouter, Switch, Route } from "react-router-dom";
import Header from "./components/Header";
import LoginComponent from "./components/LoginComponent";
import StudentList from "./components/StudentList";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import { Table } from "react-bootstrap";

const Home = () => <span>Home</span>;

const About = () => <span>About</span>;

const Users = () => <span>Users</span>;

const App = () => (
  <MemoryRouter>
    <Header />
    <Switch>
      <Route path="/studentlist">
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>First Name</th>
              <th>Last Name</th>
            </tr>
          </thead>
          <StudentList />
        </Table>
      </Route>
      <Route path="/login">
        <LoginComponent />
      </Route>
      <Route path="/about">
        <About />
      </Route>
      <Route path="/users">
        <Users />
      </Route>
      <Route path="/">
        <Home />
      </Route>
    </Switch>
  </MemoryRouter>
);

export default App;
