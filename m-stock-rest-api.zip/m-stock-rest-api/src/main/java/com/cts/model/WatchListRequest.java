package com.cts.model;



public class WatchListRequest {

	private int userId;
	private int companyId;
	
	public WatchListRequest() {
	}

	public WatchListRequest(int userId, int companyId) {
		super();
		this.userId = userId;
		this.companyId = companyId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	
	
}
