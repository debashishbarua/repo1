package com.example.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "HELLO-SERVICE")
public interface HelloFeignClient {
	
	@GetMapping("/hello")
	public String sayHello();

}
