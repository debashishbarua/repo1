package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EmployeeService {

	/**
	 * Used to communicate with Repository
	 */
	@Autowired
	private EmployeeRepository repository;

	/**
	 * 
	 * @param employee
	 * @return
	 */
	public Employee createEmployee(Employee employee) {
		return repository.save(employee);
	}

	/**
	 * 
	 * @return
	 */
	public List<Employee> findAll() {

		return repository.findAll();
	}

	/**
	 * Used to find the Employee based on id
	 * 
	 * @param id
	 * @return
	 * @throws EmployeeNotFoundException
	 */
	public Employee findById(int id) throws EmployeeNotFoundException {
		log.info("Start");
		log.debug("ID :{}", id);
		Optional<Employee> optionEmployee = repository.findById(id);
		if (optionEmployee.isEmpty()) {
			throw new EmployeeNotFoundException("Exployee Not Exists with id: " + id);
		}
		log.info("End");
		return optionEmployee.get();
	}

	public void deleteById(int id) throws EmployeeNotFoundException {
		log.info("Start");
		log.debug("ID :{}", id);
		try {
			Employee employee = this.findById(id);
			log.debug("Employee:{}" + employee);
			repository.deleteById(id);
		} catch (EmployeeNotFoundException e) {
			log.error("Error:{}", e.getMessage());
			throw e;
		}
		log.info("End");

	}

	public Employee updateEmployee(int id,Employee employee) {
		log.info("Start");
		log.debug("ID :{}", id);
		try {
			Employee employeeFromDb = this.findById(id);
			log.debug("Employee:{}" + employeeFromDb);
			return repository.save(employee);
		} catch (EmployeeNotFoundException e) {
			log.error("Error:{}", e.getMessage());
			throw e;
		}
		
		
	}

}
