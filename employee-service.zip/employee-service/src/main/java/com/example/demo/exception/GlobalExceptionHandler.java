package com.example.demo.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<Object> handleEmployeeNotFoundException( EmployeeNotFoundException e){
		ExceptionResponse body=new ExceptionResponse(new Date(), e.getMessage(), HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}

}
