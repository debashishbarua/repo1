package com.example.demo.service;

import static org.mockito.ArgumentMatchers.anyInt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
 class EmployeeServiceTest {

	@InjectMocks
	private EmployeeService employeeService;

	@Mock
	private EmployeeRepository employeeRepository;

	@Test
	void findByIdSholdReturnEmployee() throws Exception {
		
		Employee employee=new Employee(101,"Akash", "Verma");	
		
		when(employeeRepository.findById(anyInt())).thenReturn(Optional.of(employee));
		
		assertEquals(employee, employeeService.findById(anyInt()));
		
		verify(employeeRepository).findById(anyInt());

	}

	@Test
	 void findByIdSholdThrowException() throws Exception {
		
		when(employeeRepository.findById(10)).thenThrow(new EmployeeNotFoundException("Employee Not Found"));
		
		EmployeeNotFoundException exception=assertThrows(EmployeeNotFoundException.class, () ->employeeService.findById(10) );
		
		assertEquals("Employee Not Found", exception.getMessage());
		
		verify(employeeRepository).findById(anyInt());
	}

}
