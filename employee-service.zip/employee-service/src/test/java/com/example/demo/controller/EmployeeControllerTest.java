package com.example.demo.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@WebMvcTest(EmployeeController.class)
 class EmployeeControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmployeeService employeeService;
	
	
	@Test
	void findByIdTest() throws Exception {
		Employee employee = new Employee(10, "Akash", "Verma");		
		when(employeeService.findById(anyInt())).thenReturn(employee);
		
		this.mockMvc.perform(get("/employees/{id}", 10))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.firstName", is(employee.getFirstName())));
		verify(employeeService, times(1)).findById(anyInt());
	}

}
