package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class EmployeeConsumerClientController {
	
	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/employees/{id}")
	public Employee getEmployeeById(@PathVariable("id") int id) {
		log.info("START" );
		Employee employee=restTemplate.getForObject("http://localhost:9090/EMPLOYEE-SERVICE/employees/"+id, Employee.class);
		//Employee employee=restTemplate.getForObject("http://localhost:9001/employees/"+id, Employee.class);
		log.debug("Employee:{}",employee);
		log.info("END");
		return employee;
	}
}
